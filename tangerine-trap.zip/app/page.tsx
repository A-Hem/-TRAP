"use client"

import { useState, useEffect } from "react"
import { BootSequence } from "@/components/boot-sequence"
import { Terminal } from "@/components/terminal"
import { MeetTheAgents } from "@/components/meet-the-agents"
import { WhyJoin } from "@/components/why-join"
import { Footer } from "@/components/footer"
import { LoadingMessages } from "@/components/loading-messages"

export default function Home() {
  const [isBooted, setIsBooted] = useState(false)
  const [showContent, setShowContent] = useState(false)

  useEffect(() => {
    if (isBooted) {
      const timer = setTimeout(() => setShowContent(true), 1000)
      return () => clearTimeout(timer)
    }
  }, [isBooted])

  return (
    <div className="min-h-screen bg-slate-900 text-emerald-500 font-mono">
      {!isBooted ? (
        <BootSequence onComplete={() => setIsBooted(true)} />
      ) : (
        <>
          <div className="fixed inset-0 pointer-events-none">
            <div className="absolute inset-0 bg-scanline opacity-5"></div>
            <div className="absolute inset-0 animate-glow"></div>
          </div>
          <main className="container mx-auto p-4 pt-8 space-y-12">
            <h1 className="text-4xl md:text-6xl font-bold text-center mb-4 text-orange-500">
              $ make crypto_zesty_again
            </h1>
            <p className="text-xl text-center mb-8 text-emerald-400">
              // A decentralized playground where frens split GPU power, profits, and vitamin C.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <a
                href="#"
                className="bg-orange-500 text-slate-900 px-6 py-2 rounded hover:bg-orange-600 transition-colors text-center"
              >
                $ git clone https://trap.based
              </a>
              <a
                href="#"
                className="border border-orange-500 text-orange-500 px-6 py-2 rounded hover:bg-orange-500 hover:text-slate-900 transition-colors text-center"
              >
                $ cd ./citrus_miner
              </a>
            </div>
            <Terminal />
            <MeetTheAgents />
            <WhyJoin />
          </main>
          <Footer />
          <LoadingMessages />
        </>
      )}
    </div>
  )
}

