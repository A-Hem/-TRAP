import "@/styles/globals.css"
import { Inter } from "next/font/google"
import type { ReactNode } from "react"

const inter = Inter({ subsets: ["latin"] })

export const metadata = {
  title: "🍊Trap - Zesty Crypto Mining for the New Internet",
  description:
    "Join the movement to make crypto zesty again. Split GPU power, profits, and vitamin C with Tangerine Trap ($🍊TRAP).",
}

export default function RootLayout({
  children,
}: {
  children: ReactNode
}) {
  return (
    <html lang="en">
      <body className={`${inter.className} bg-slate-900 text-emerald-500`}>{children}</body>
    </html>
  )
}



import './globals.css'