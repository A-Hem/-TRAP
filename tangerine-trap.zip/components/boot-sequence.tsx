"use client"

import { useState, useEffect } from "react"

const BOOT_MESSAGES = [
  "$ ./tangerine_trap --init",
  "LOADING $🍊TRAP v1.0...",
  "AGENTIC MINERS: [▓▓▓▓▓▓▓▓▓▓] 100%",
  "TANGERINE MODE: ACTIVATED 🍊",
]

export function BootSequence({ onComplete }: { onComplete: () => void }) {
  const [currentMessage, setCurrentMessage] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentMessage((prev) => {
        if (prev >= BOOT_MESSAGES.length - 1) {
          clearInterval(interval)
          setTimeout(onComplete, 1000)
          return prev
        }
        return prev + 1
      })
    }, 1000)

    return () => clearInterval(interval)
  }, [onComplete])

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-900">
      <div className="space-y-2">
        {BOOT_MESSAGES.slice(0, currentMessage + 1).map((message, i) => (
          <div key={i} className="flex items-center space-x-2">
            <span className="text-orange-500">❯</span>
            <span className="typing-animation text-emerald-500">{message}</span>
          </div>
        ))}
      </div>
    </div>
  )
}

