const REASONS = [
  {
    title: "NO VC PEELS",
    description: "We're like Uniswap, but with fewer degens and more vitamin C.",
  },
  {
    title: "OPEN SOURCE, OPEN JUICE",
    description: "Our code is audited. Our memes are 100% pulp-free.",
  },
  {
    title: "AGENTIC WORKFLOWS",
    description: "Your GPU mines, our agents meme. Synergy!",
  },
]

export function WhyJoin() {
  return (
    <section className="space-y-8">
      <h2 className="text-3xl font-bold text-center text-orange-500">Why Join?</h2>
      <div className="grid md:grid-cols-3 gap-8">
        {REASONS.map((reason, index) => (
          <div key={index} className="border border-orange-500 rounded-lg p-4 bg-slate-800">
            <h3 className="text-xl font-bold mb-2 text-orange-500">{reason.title}</h3>
            <p className="text-emerald-400">{reason.description}</p>
          </div>
        ))}
      </div>
    </section>
  )
}

