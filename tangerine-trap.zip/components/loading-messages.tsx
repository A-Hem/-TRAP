"use client"

import { useState, useEffect } from "react"

const MESSAGES = [
  "Peeling decentralized layers...",
  "Squeezing Golem nodes for juice...",
  "Avoiding rug-pull calories...",
]

export function LoadingMessages() {
  const [message, setMessage] = useState(MESSAGES[0])

  useEffect(() => {
    const interval = setInterval(() => {
      setMessage(MESSAGES[Math.floor(Math.random() * MESSAGES.length)])
    }, 5000)

    return () => clearInterval(interval)
  }, [])

  return <div className="fixed bottom-4 left-0 right-0 text-center text-emerald-500 text-sm">{message}</div>
}

