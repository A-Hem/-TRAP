import type React from "react"

interface CommandOutputProps {
  output: string | { title: string; content: string[] }
}

export const CommandOutput: React.FC<CommandOutputProps> = ({ output }) => {
  if (typeof output === "string") {
    return <pre className="text-emerald-500 whitespace-pre-wrap">{output}</pre>
  }

  return (
    <div>
      <pre className="text-emerald-500 whitespace-pre-wrap">{output.title}</pre>
      {output.content.map((line, index) => (
        <pre key={index} className="text-emerald-500 whitespace-pre-wrap">
          {line}
        </pre>
      ))}
    </div>
  )
}

