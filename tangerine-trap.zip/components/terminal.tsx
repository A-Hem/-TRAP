"use client"

import { useState, useEffect, useRef } from "react"
import { CommandOutput } from "./command-output"

const COMMANDS = {
  help: "Available commands: help, trapmine, agents, why, clear",
  trapmine: {
    title: "$ ./trapmine --target 0x🍊",
    content: [
      'SEARCHING FOR "0x🍊TRAP"...',
      "AGENT #420 FOUND MATCH! 🎉",
      "PRIVATE KEY: 0x... (citrus-secured 🍊)",
      "REWARDS SPLIT:",
      "- YOU: 50% (🤑)",
      "- FRENS: 30% (👯)",
      "- $🍊TRAP: 20% (not a rug, we swear)",
    ],
  },
  agents: "Use the 'agents' command to view individual agent profiles.",
  why: "Use the 'why' command to see why you should join Tangerine Trap.",
  clear: null,
  "sudo squeeze": "ERROR: Juice not found. Try $🍊TRAP instead.",
}

const TANGERINE_ASCII = `
   .---.
  /     \\
 |   🍊   |
  \\_____/
`

export function Terminal() {
  const [history, setHistory] = useState<Array<{ command: string; output: any }>>([])
  const [input, setInput] = useState("")
  const inputRef = useRef<HTMLInputElement>(null)
  const historyRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    inputRef.current?.focus()
  }, [])

  useEffect(() => {
    if (historyRef.current) {
      historyRef.current.scrollTop = historyRef.current.scrollHeight
    }
  }, [historyRef])

  const handleCommand = (cmd: string) => {
    const command = cmd.toLowerCase().trim()

    if (command === "clear") {
      setHistory([])
      return
    }

    const output =
      COMMANDS[command as keyof typeof COMMANDS] || "Command not found. Type 'help' for available commands."

    setHistory((prev) => [
      ...prev,
      {
        command,
        output: command === "trapmine" ? TANGERINE_ASCII + "\n" + output : output,
      },
    ])
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim()) return

    handleCommand(input)
    setInput("")
  }

  return (
    <div className="bg-slate-800 border border-orange-500 rounded-lg p-4">
      <div
        ref={historyRef}
        className="h-64 overflow-y-auto mb-4 scrollbar-thin scrollbar-track-slate-800 scrollbar-thumb-orange-500"
      >
        {history.map((entry, i) => (
          <div key={i} className="mb-2">
            <div className="flex items-center text-orange-500">
              <span className="mr-2">user@tangerinetrap:~$</span>
              <span>{entry.command}</span>
            </div>
            <CommandOutput output={entry.output} />
          </div>
        ))}
      </div>

      <form onSubmit={handleSubmit} className="flex items-center">
        <span className="text-orange-500 mr-2">user@tangerinetrap:~$</span>
        <input
          ref={inputRef}
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          className="flex-1 bg-transparent border-none outline-none text-emerald-500"
          autoFocus
        />
      </form>
    </div>
  )
}

