export function Footer() {
  return (
    <footer className="mt-12 border-t border-orange-500 py-8 bg-slate-800">
      <div className="container mx-auto px-4">
        <p className="text-center mb-4 text-emerald-400">
          TRUSTED BY: 0xSatoshi (allegedly), Vitalik's grocery list, Your juicer (RIP).
        </p>
        <p className="text-center text-sm text-orange-500">
          *Not financial advice. Side effects may include zestiness, existential zest, and GPU-induced vitamin C
          overdose.
        </p>
        <div className="flex justify-center mt-4 space-x-4">
          <a href="ssh://discord://tangerine_frens" className="text-orange-500 hover:text-orange-400">
            [DISCORD]
          </a>
          <a href="https://basescan.org/token/0x..." className="text-orange-500 hover:text-orange-400">
            [BASE SCAN]
          </a>
        </div>
      </div>
    </footer>
  )
}

