const AGENTS = [
  {
    id: "001",
    name: "Mandy Mandarin",
    specialty: "Mining 0x🍊TRAP while avoiding scurvy",
  },
  {
    id: "002",
    name: "Zesty the Golem Node",
    specialty: "Runs on tangerine juice and spite. Faster than your ex's rebound.",
  },
  {
    id: "003",
    name: "Pulp the Brute-Forcer",
    specialty: "Squeezes GPUs until they cry 'uncle' (or ETH).",
  },
]

export function MeetTheAgents() {
  return (
    <section className="space-y-8">
      <h2 className="text-3xl font-bold text-center text-orange-500">Meet the Agents</h2>
      <div className="grid md:grid-cols-3 gap-8">
        {AGENTS.map((agent) => (
          <div key={agent.id} className="border border-orange-500 rounded-lg p-4 text-center bg-slate-800">
            <pre className="text-orange-500 mb-4 text-xs sm:text-sm md:text-base whitespace-pre-wrap">
              {`
╔════════════════════╗
║    AGENT #${agent.id}      ║
║  "${agent.name}"   ║
║  SPECIALTY: ${agent.specialty.slice(0, 16)}║
║  ${agent.specialty.slice(16, 32)}║
║  ${agent.specialty.slice(32, 48)}║
╚════════════════════╝
              `.trim()}
            </pre>
            <p className="text-sm text-emerald-400">{agent.specialty}</p>
          </div>
        ))}
      </div>
    </section>
  )
}

